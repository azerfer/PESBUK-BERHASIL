<?php if(session('pesan')): ?>
<div class="alert alert-primary" role="alert">
    <b>status</b> : <?php echo e(session('pesan')); ?>

</div>
<?php endif; ?>