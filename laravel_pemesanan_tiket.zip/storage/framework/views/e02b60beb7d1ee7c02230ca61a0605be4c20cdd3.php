<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Kategori</div>
                
                    <div class="card-body">
                            <td><a href="<?php echo e(route('kategori.create')); ?>" class="btn btn-danger btn-sm"> tambah kategori </a></td>
                            
                    </div>
                    <?php echo $__env->make('notifikasi', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <table class="table table-bordered" id="users-table">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Kategori</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no=1; ?>
                        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                        
                        <tr>
                            <td><?php echo e($no); ?></td>
                            <td><?php echo e($item->nama_kategori); ?></td>
                            <td><a href="<?php echo e(route('kategori.edit',$item->id)); ?>" class="btn btn-danger btn-sm"> Edit </a></td>
                            <?php echo Form::open(['route'=>['kategori.destroy',$item->id],'method'=>'DELETE']); ?>

                            <td><button type="submit" name="submit" class="btn btn-danger btn-sm"> Delete </button></td>
                            <?php echo Form::close(); ?>

                        </tr>
                        <?php $no++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>


                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(function() {
$('#users-table').DataTable();
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>