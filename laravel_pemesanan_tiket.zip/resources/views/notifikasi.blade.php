@if (session('pesan'))
<div class="alert alert-primary" role="alert">
    <b>status</b> : {{ session('pesan') }}
</div>
@endif